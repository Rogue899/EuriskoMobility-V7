'use strict';
var express = require("express");
var bodyParser = require("body-parser");
var mongoose = require("mongoose");
var methodOverride = require("method-override");
var app = express();
var Note = require("./models/note");


var tagRoutes   = require("./routes/tags"),
    noteRoutes  = require("./routes/notes");


mongoose.connect("mongodb://localhost/notesDB", { useNewUrlParser: true });
app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(methodOverride("_method"));
mongoose.set('useFindAndModify', false);
app.use(tagRoutes);
app.use(noteRoutes);

app.get("/", function (req, res) {
    res.redirect("/notes");
 
});


app.get("/notes", function (req, res) {
    if (req.query.search) {
        const regex = new RegExp(escapeRegex(req.query.search), 'gi');
        Note.find({ category: regex }).populate("tags").exec(function (err, notes) {
            if (err) {
                console.log(err);
            } else {
                res.render("index", { notes: notes});
            }
        });
    }
    else {
    Note.find({}).populate("tags").exec(function (err, notes) {
        if (err) {
            console.log(err);
        } else {
            res.render("index", { notes: notes });


        }
    });
}

});

function escapeRegex(text) {
    return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
}


app.listen(3000, function () {
    console.log('Server Started');
});
