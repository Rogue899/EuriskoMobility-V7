var mongoose = require("mongoose");
var noteSchema = new mongoose.Schema({
    title: String,
    body: String,
    category: String,
    created: { type: Date, default: Date.now },
    tags: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Tag"
        }
    ]
});

module.exports = mongoose.model("Note", noteSchema);

