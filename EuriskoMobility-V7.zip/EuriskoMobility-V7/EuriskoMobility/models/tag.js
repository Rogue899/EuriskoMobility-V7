var mongoose = require("mongoose");


var tagSchema = new mongoose.Schema({
    tagDescription: String
});

module.exports = mongoose.model("Tag", tagSchema);
