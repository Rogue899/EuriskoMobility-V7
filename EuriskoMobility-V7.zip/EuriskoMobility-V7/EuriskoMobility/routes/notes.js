var express = require("express");
var router = express.Router();
var Note = require("../models/note");



router.post("/", function (req, res) {
    res.redirect("/notes");
});


//new
router.get("/notes/new", function (req, res) {
    res.render("notes/new");
});

//create
router.post("/notes", function (req, res) {
    Note.create(req.body.note, function (err, newNote) {
        if (err) {
            console.log(err);
        } else {
            res.redirect("/notes");
        }
    });

});

//show
router.get("/notes/:id", function (req, res) {
    Note.findById(req.params.id).populate("tags").exec(function (err, foundNote) {
        if (err) {
            console.log(err);
        } else {
            res.render("notes/show", { note: foundNote });
        }
    });
});

//edit
router.get("/notes/:id/edit", function (req, res) {
    Note.findById(req.params.id, function (err, foundNote) {
        if (err) {
            console.log(err);
        } else {
            res.render("notes/edit", { note: foundNote });
        }
    });
});
//update
router.put("/notes/:id", function (req, res) {
    Note.findByIdAndUpdate(req.params.id, req.body.note, function (err, updatedNote) {
        if (err) {
            console.log(err);
            res.redirect("/notes");
        } else {
            res.redirect("/notes/" + req.params.id);
        }
    });
});
//delete
router.delete("/notes/:id", function (req, res) {
    Note.findByIdAndRemove(req.params.id, function (err) {
        if (err) {
            console.log(err);
        } else {
            res.redirect("/notes");
        }
    });
});

module.exports = router;