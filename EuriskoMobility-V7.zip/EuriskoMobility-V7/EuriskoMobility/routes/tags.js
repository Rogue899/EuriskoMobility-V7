var express = require("express");
var router = express.Router();
var Note = require("../models/note");
var Tag = require("../models/tag");


//Adding tags

router.post("/notes/:id/tags", function (req, res) {
    Note.findById(req.params.id, function (err, note) {
        if (err) {
            res.redirect("/notes");
        }
        else {
            Tag.create(req.body.tag, function (err, tag) {
                if (err) {
                    console.log(err);
                }
                else {
                    note.tags.push(tag);
                    note.save();
                    res.redirect("/notes");
                }
            });
        }
    });
});

//remove tags
router.delete("/notes/:id/tags/:tag_id", function (req, res) {
    Tag.findByIdAndRemove(req.params.tag_id, function (err) {
        if (err) {
            console.log(err);
            res.redirect("/notes");
        }
        else {
            res.redirect("/notes");
        }
    });
});

module.exports = router;